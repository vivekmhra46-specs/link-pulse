from flask import Flask, request, jsonify, redirect, send_from_directory
import sqlite3, re
from datetime import datetime
from urllib.parse import urlparse
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / "linkpulse.db"
app = Flask(__name__)

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS links (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            url TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
            tag TEXT DEFAULT 'General', clicks INTEGER DEFAULT 0,
            created TEXT NOT NULL)""")

def valid_url(url):
    try:
        p = urlparse(url)
        return p.scheme in ("http", "https") and bool(p.hostname) and not any(x.isspace() for x in url)
    except Exception:
        return False

def slug_ok(s):
    return bool(re.fullmatch(r"[A-Za-z0-9_-]{3,40}", s or ""))

def make_slug(url):
    host = (urlparse(url).hostname or "link").lower().replace("www.", "")
    base = re.sub(r"[^a-z0-9_-]", "-", host.split(".")[0])[:18] or "link"
    slug, i = base, 2
    with connect() as c:
        while c.execute("SELECT 1 FROM links WHERE slug=?", (slug,)).fetchone():
            slug, i = f"{base}-{i}", i + 1
    return slug

@app.get("/")
def home():
    return send_from_directory(BASE, "index.html")

@app.get("/api/links")
def list_links():
    with connect() as c:
        return jsonify([dict(r) for r in c.execute("SELECT * FROM links ORDER BY id DESC")])

@app.post("/api/links")
def create_link():
    d = request.get_json(silent=True) or {}
    url, title = str(d.get("url","")).strip(), str(d.get("title","")).strip()
    slug, tag = str(d.get("slug","")).strip(), str(d.get("tag","General")).strip() or "General"
    if not valid_url(url):
        return jsonify(error="Enter a valid URL beginning with http:// or https://."), 400
    title = title or urlparse(url).hostname or "Untitled link"
    if slug and not slug_ok(slug):
        return jsonify(error="Custom slug must be 3–40 characters using letters, numbers, - or _."), 400
    if not slug:
        slug = make_slug(url)
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with connect() as c:
            c.execute("INSERT INTO links(title,url,slug,tag,clicks,created) VALUES(?,?,?,?,0,?)",
                      (title,url,slug,tag,created))
            row = c.execute("SELECT * FROM links WHERE slug=?", (slug,)).fetchone()
            return jsonify(dict(row)), 201
    except sqlite3.IntegrityError:
        return jsonify(error="That short-link name already exists. Choose another."), 409

@app.post("/api/safety-check")
def safety_check():
    d = request.get_json(silent=True) or {}
    url = str(d.get("url","")).strip()
    if not valid_url(url):
        return jsonify(level="danger", heading="Invalid URL", body="Enter a complete HTTP or HTTPS URL."), 400
    p = urlparse(url)
    if p.scheme != "https":
        return jsonify(level="warning", heading="HTTP connection", body="This URL does not use HTTPS. This is only a basic check and does not prove a site is malicious.")
    return jsonify(level="safe", heading="No obvious warning detected", body="This basic demo cannot guarantee that a URL is safe.")

@app.patch("/api/links/<slug>")
def edit_link(slug):
    title = str((request.get_json(silent=True) or {}).get("title","")).strip()
    if not title:
        return jsonify(error="Title cannot be empty."), 400
    with connect() as c:
        cur = c.execute("UPDATE links SET title=? WHERE slug=?", (title,slug))
        if not cur.rowcount: return jsonify(error="Link not found."), 404
        return jsonify(dict(c.execute("SELECT * FROM links WHERE slug=?", (slug,)).fetchone()))

@app.delete("/api/links/<slug>")
def delete_link(slug):
    with connect() as c:
        cur = c.execute("DELETE FROM links WHERE slug=?", (slug,))
        if not cur.rowcount: return jsonify(error="Link not found."), 404
    return jsonify(message="Deleted")

@app.get("/go/<slug>")
def go(slug):
    with connect() as c:
        row = c.execute("SELECT url FROM links WHERE slug=?", (slug,)).fetchone()
        if not row: return "Short link not found.", 404
        target = row["url"]
        c.execute("UPDATE links SET clicks=clicks+1 WHERE slug=?", (slug,))
    return redirect(target, 302)

@app.get("/<path:filename>")
def static_files(filename):
    if filename.endswith((".css",".js",".png",".jpg",".svg",".ico",".webp")):
        return send_from_directory(BASE, filename)
    return jsonify(error="Not found"), 404

if __name__ == "__main__":
    init_db()
    print("LinkPulse running at http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
